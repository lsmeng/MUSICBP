evtlst_char=['af04_M51';'af06_M52';'af08_M52'];
evtlst_name=['af04_M51';'af06_M52';'af08_M52'];

save evtlst.mat evtlst_char evtlst_name
