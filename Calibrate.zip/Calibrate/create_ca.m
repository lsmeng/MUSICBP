lat_ap=[34.44;34.41;34.65];
lat_ca=[34.49;34.43;34.70];
lon_ap=[99.03;99.28;98.09];
lon_ca=[98.91;99.14;98.03];
lat_cali=[];
lon_cali=[];

save ca_ap_loc.mat lat_ca lat_ap lon_ca lon_ap lat_cali lon_cali