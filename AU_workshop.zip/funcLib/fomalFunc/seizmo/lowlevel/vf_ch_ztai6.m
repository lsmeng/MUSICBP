function [head]=vf_ch_ztai6(def,head,value)
%VF_CH_ZTAI6    Sets virtual field ZTAI6

% just pass on to vf_ch_ztai
head=vf_ch_ztai(def,head,value);


end
