function [value]=vf_lh_ztai6(def,head)
%VF_LH_ZTAI6    Returns value for virtual field ZTAI6 as a string

% just pass on to vf_lh_ztai
value=vf_lh_ztai(def,head);

end
